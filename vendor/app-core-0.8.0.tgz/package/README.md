# app-core

Felles pakke for alle apper fra Olstad Digital, fra Saldo Pocket og fremover (ikke PlanTravel).
Alt som skal være likt i flere apper, ligger her én gang. Det kopieres aldri mellom apper.

## Innhold

| Inngang | Hva | React Native? |
|---|---|---|
| `app-core` | Språkliste (18 språk: kode, eget navn, rtl, felles tekster), `resolveLanguage`, `defineAppLanguages`; 47 valutaer, reserve USD, BGN → EUR; valutanavn på alle 18 språk; `formatMoney`, `formatDate`, `formatNumber`, `formatPercent`, `toMinor`/`fromMinor`, `roundPrice`/`priceStep`, søk; reglene for aktivt språk og aktiv valuta (`*AutoSet`) | Nei |
| `app-core/countries` | Landkoder (ISO 3166-1) og landnavn på alle 18 språk | Nei |
| `app-core/holidays` | Helligdager og bankfridager per land (2025–2032, kilde date-holidays CC-BY-3.0, generert), helgedager per land, `isNonWorkingDay`; fallback bare helg | Nei |
| `app-core/polyfills` | `Intl.PluralRules` (Hermes mangler den) | Nei |
| `app-core/expo` | `createPreferences` (lagring + hooks, `getActiveLanguage`/`getActiveCurrency`), `createI18n` (i18next, appens tekster + `core.*`, native RTL med omstart ved retningsbytte), `createUseFormat` | Ja |
| `app-core/checks` | Sjekk av appens språkfiler og WCAG-kontrast, for appens byggeskript | Node |
| `app-core/eslint` | Vaktreglene (tekst, farger, locale, Intl, toFixed, start/end, faste bredder) | Node |

Blir i hver app: appens egne tekster, tema og farger, kategorier, gratis/Pro og forretningsregler.

Felles UI-tekster (`t('core.<nøkkel>')`): `ok`, `cancel`, `save`, `delete`, `retry`, `errorTitle`, `errorBody`,
`offlineTitle`, `offlineBody`, `loading`, `emptyTitle`, `restartingForDirection`.

Språk: en, es, pt-BR, fr, de, it, ja, ko, zh-Hans, nb, nl, sv, pl, fi, da, ar (rtl), hi, tr.

## Regler

- Ingen React Native i `src/` utenfor `src/expo/` (ESLint stopper det). Kjernen brukes også på server og web.
- Beløp som heltall i minste enhet + ISO-valutakode. Datoer i ISO 8601. Ingen fast locale.
- `npm run check` må være grønt før tag: typer, lint, tester og datasjekk (alle tekster, valutanavn og landnavn på alle språk).

## Nytt språk

- **Språket finnes i app-core:** én språkfil og én linje i appens `languages.ts`. Ingen endring her.
- **Helt nytt språk:** én fil i `src/texts/<kode>.ts`, import + én linje i `src/languages.ts`,
  `npm run generate:names` (valuta- og landnavn fra CLDR, håndrettinger beholdes), `npm run check`, ny versjon.

## Installasjon i en app

Pakken er privat. EAS skal ikke ha en GitHub-nøkkel, så appen har pakken som fil i sitt eget repo:

```
"app-core": "file:vendor/app-core-0.1.0.tgz"
```

Oppdatering i appen: `npm run core:update -- 0.2.0`. Skriptet henter taggen `v0.2.0` med din lokale `gh`-innlogging,
bygger og pakker den (`npm pack`), legger filen i `vendor/`, fjerner den gamle, oppdaterer `package.json` og lockfilen.
Kjør så `npm run check`, test, commit.

- Metro: vanlig JavaScript (ESM) med typer. Ingen native kode.
- OTA: app-core ligger i JavaScript-bundelen. En ny versjon når brukerne med OTA så lenge den ikke krever en ny native pakke.
- EAS-build: filen ligger i repoet, ingen hemmeligheter.

## Versjoner

Semver med tag `vX.Y.Z` og en linje i `CHANGELOG.md`. Hver app oppdaterer når det passer.

1. Endre, `npm run check`.
2. Øk `version` i `package.json`, skriv i `CHANGELOG.md`, commit.
3. `git tag vX.Y.Z && git push --follow-tags`.

## Neste versjon (planlagt)

- **Valutaomregning og kursklient.** Én felles kurstjeneste for alle apper (samme kilder, samme cache, daglig oppdatering).
  Omregning med heltall, avrundet etter valutaens desimaler. Lagre original beløp + valuta og omregnet beløp + valuta +
  kurs + kursdato. Siste kurser lokalt, så omregning virker uten nett, og kursdatoen vises. Mangler kursen, vises det med
  en språknøkkel, aldri som 0. Saldo Pocket trenger dette når flere valutaer i samme budsjett kommer.
