// Shared lint guards for the global rules (text, colors, locale, Intl, toFixed, start/end,
// fixed widths, Hermes on iOS). Use in an app's eslint.config.js:
//   const { restrictSyntax, restrictedImports } = require('app-core/eslint');
//   rules: { 'no-restricted-syntax': restrictSyntax(), 'no-restricted-imports': restrictedImports() }
// and allow a group only in the one folder that may do that thing, e.g.
//   files: ['src/shared/theme/**'], rules: { 'no-restricted-syntax': restrictSyntax('color') }

const TEXT_PROP =
  'JSXAttribute[name.name=/^(title|label|placeholder|accessibilityLabel|accessibilityHint|aria-label|alt)$/]';

const GUARDS = {
  text: [
    {
      selector: 'JSXText[value=/\\S/]',
      message: 'Hardcoded text in JSX. Put it in the language files and use t().',
    },
    {
      selector: ':matches(JSXElement, JSXFragment) > JSXExpressionContainer > :matches(Literal[value=/\\S/], TemplateLiteral)',
      message: 'Hardcoded text in JSX. Put it in the language files and use t().',
    },
    {
      selector: `${TEXT_PROP} > Literal[value=/\\S/]`,
      message: 'Hardcoded user-visible text in a prop. Use t().',
    },
    {
      selector: `${TEXT_PROP} > JSXExpressionContainer > :matches(Literal[value=/\\S/], TemplateLiteral)`,
      message: 'Hardcoded user-visible text in a prop. Use t().',
    },
  ],
  color: [
    {
      selector: 'Literal[value=/^#([0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/]',
      message: 'Hex color outside the theme. Add a token with a light and a dark value.',
    },
    {
      selector: 'Literal[value=/^(rgb|rgba|hsl|hsla)\\(/i]',
      message: 'Color value outside the theme. Add a token with a light and a dark value.',
    },
    {
      selector: 'Property[key.name=/[cC]olor$/] > Literal[value=/^[a-z]+$/]:not([value="transparent"])',
      message: 'Named color outside the theme. Use a theme token.',
    },
  ],
  locale: [
    {
      selector: 'Literal[value=/^[a-z]{2,3}([-_][A-Z][a-z]{3})?[-_]([A-Z]{2}|[0-9]{3})$/]',
      message: 'Fixed locale. Formatting must use the user locale (app-core format functions).',
    },
  ],
  intl: [
    {
      selector: 'MemberExpression[object.name="Intl"]',
      message: 'Intl is used only inside app-core. Use formatMoney/formatDate/formatPercent/formatNumber.',
    },
    {
      selector: 'MemberExpression[property.name=/^toLocale(String|DateString|TimeString)$/]',
      message: 'Use the app-core format functions instead of toLocale*().',
    },
  ],
  toFixed: [
    {
      selector: 'MemberExpression[property.name="toFixed"]',
      message: 'toFixed is banned (rounds floats, ignores locale). Store minor units and use formatMoney/formatNumber.',
    },
  ],
  direction: [
    {
      selector:
        'Property[key.name=/^(left|right|marginLeft|marginRight|paddingLeft|paddingRight|borderLeftWidth|borderRightWidth|borderLeftColor|borderRightColor|borderTopLeftRadius|borderTopRightRadius|borderBottomLeftRadius|borderBottomRightRadius)$/]',
      message: 'Use start/end (marginStart, paddingEnd, start, borderStartWidth…) so right-to-left works.',
    },
    {
      selector: 'Property[key.name=/^(textAlign|alignSelf|alignItems|justifyContent)$/] > Literal[value=/^(left|right)$/]',
      message: 'Use start/end/auto instead of left/right so right-to-left works.',
    },
  ],
  // Hermes on iOS lacks these (app-core 0.6.0 crashed every iOS screen with formatToParts).
  // Use the plain formatted text instead, or a guarded fallback with a reasoned eslint-disable line.
  hermes: [
    {
      selector: 'MemberExpression[property.name="formatToParts"]',
      message: 'Hermes on iOS has no formatToParts: it throws and crashes the app. Read the formatted text instead (see app-core numberSeparators).',
    },
    {
      selector: 'MemberExpression[object.name="Intl"][property.name=/^(Locale|DisplayNames|RelativeTimeFormat|ListFormat|Segmenter|supportedValuesOf)$/]',
      message: 'Not available in Hermes on iOS: crashes the app there. Generate the data at build time (like currency and country names) or add a fallback.',
    },
  ],
  width: [
    {
      selector: 'Property[key.name=/^(width|minWidth|maxWidth)$/] > Literal[raw=/^[1-9]/]',
      message: 'No fixed widths: text grows 30–40 % in some languages and with large system fonts. Use flex, padding or %.',
    },
  ],
};

/** 'no-restricted-syntax' with every guard group except the allowed ones. */
function restrictSyntax(...allowed) {
  return [
    'error',
    ...Object.entries(GUARDS)
      .filter(([group]) => !allowed.includes(group))
      .flatMap(([, selectors]) => selectors),
  ];
}

/** Date picker packages: every calendar goes through app-core's DatePickerSheet (one look, all apps). */
const DATE_PICKER_PACKAGES = [
  '@react-native-community/datetimepicker',
  'react-native-calendars',
  'react-native-modal-datetime-picker',
  'react-native-date-picker',
  'react-native-ui-datepicker',
  'react-native-paper-dates',
];

/**
 * 'no-restricted-imports': Text and useColorScheme only through the app's own components/theme,
 * and no date picker packages (use DatePickerSheet from app-core/expo).
 */
function restrictedImports() {
  return [
    'error',
    {
      paths: [
        {
          name: 'react-native',
          importNames: ['Text', 'useColorScheme'],
          message: "Use the app's Text component and useTheme().",
        },
        ...DATE_PICKER_PACKAGES.map((name) => ({
          name,
          message: 'Every calendar goes through DatePickerSheet from app-core/expo, so all apps look and behave the same.',
        })),
      ],
    },
  ];
}

module.exports = { GUARDS, DATE_PICKER_PACKAGES, restrictSyntax, restrictedImports };
